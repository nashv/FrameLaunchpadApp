window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Frame Launchpad",
   "homepage": "https://app.fra.me",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "kioskEnabled": false
};